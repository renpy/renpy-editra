###############################################################################
# Name: __init__.py                                                           #
# Purpose: Eclib test package                                                 #
# Author: Cody Precord <cprecord@editra.org>                                  #
# Copyright: (c) 2009 Cody Precord <staff@editra.org>                         #
# Licence: wxWindows Licence                                                  #
###############################################################################

"""
Editra Control Library Test Package

"""

__author__ = "Cody Precord <cprecord@editra.org>"
__svnid__ = "$Id: __init__.py 61806 2009-09-02 01:31:01Z CJP $"
__revision__ = "$Revision: 61806 $"
